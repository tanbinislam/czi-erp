<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class MaterialRecipeController extends Controller{
    public function __construct(){
      $this->middleware('auth');
    }

    public function index(){

    }

    public function add(){

    }

    public function edit($slug){

    }

    public function view($slug){

    }

    public function insert(){

    }

    public function update(){

    }

    public function softdelete(){

    }

    public function restore(){

    }

    public function delete(){

    }
}

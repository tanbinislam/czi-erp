<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        // \App\Models\User::factory(10)->create();
        // Add Blood Groups Info
        $blood_groups = [
            'A+' => 'a_possitive',
            'A-' => 'a_negative',
            'B+' => 'b_possitive',
            'B-' => 'b_negative',
            'O+' => 'o_possitive',
            'O-' => 'o_negative',
            'AB+' => 'ab_possitive',
            'AB-' => 'ab_negative',
            'No Blood Record' => 'no_blood_record'
        ];
        foreach($blood_groups as $group => $g_slug){
            \App\Models\BloodGroup::create([
                'blood_name' => $group,
                'blood_slug' => $g_slug,
                'blood_status' => 1,
            ]);
        }
    }
}
